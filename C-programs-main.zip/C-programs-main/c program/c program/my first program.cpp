#include<stdio.h>
int main ()
 {
printf("I am god");
	return 0;
}

