#include<stdio.h>
int main ()
{
int a,b,add;
printf("enter first value");
scanf("%d %d",&a,&b);


add=a+b;
printf("the total iss");
printf(" sum %d\n",add);

return 0;
}

