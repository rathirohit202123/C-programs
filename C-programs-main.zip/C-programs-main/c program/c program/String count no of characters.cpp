#include<stdio.h>
#include<string.h>

int main ()
{
	char str[100];
	int count=0;
	printf("enter the vicky");
	scanf("%s",str);
	while
	(str[count]!='\0')
	{
		count++;
		printf("number of character in string %d\n",count);
		return 0;
	}
}